# Security review

This app was built with the assumption that it might hold real personal
financial data. This document explains the design decisions, what was
actually verified (as opposed to just asserted), and — most
importantly — an honest list of what's still weak.

**I was not able to run `npm install` or execute this code in a real
browser while building it** (the sandbox I built it in has no network
access). Everything below reflects careful hand-review and static
checks, not a live test. Before trusting this with real data: run
`npm install && npm run typecheck && npm run build && npm run preview`
yourself, click through every feature, and re-read `src/crypto/crypto.ts`
and `src/App.tsx` line by line — that's the whole trusted computing base.

---

## What's implemented, and why

| Requirement | Implementation | Where |
|---|---|---|
| Encrypt all financial data before storing | Entire `LedgerData` object serialized to JSON, then encrypted as one blob | `src/crypto/crypto.ts`, `src/App.tsx` |
| AES-GCM | AES-256-GCM via `crypto.subtle.encrypt/decrypt` | `src/crypto/crypto.ts` |
| PBKDF2 key derivation | PBKDF2-SHA256, 310,000 iterations (OWASP's current baseline) | `src/crypto/crypto.ts` |
| Never store the password | Password exists only as a local variable inside `deriveKey()`'s call stack; never assigned to any longer-lived variable, ref, or state | `src/crypto/crypto.ts` |
| Never store the key | `deriveKey()` creates the `CryptoKey` with `extractable: false` — the raw key bytes are never readable by JavaScript, not even by this app | `src/crypto/crypto.ts` |
| Require password each open | No session persistence of any kind; every fresh load starts at `phase: "locked"` (or `"setup"`) | `src/App.tsx` |
| Auto-lock after 10 min idle | Activity-listener hook resets a timer on mouse/keyboard/touch/scroll; timeout clears the key ref and decrypted state | `src/hooks/useInactivityLock.ts`, `src/App.tsx` |
| Wipe decrypted data on lock | `data` state → `null`, key/salt refs → `null` on every lock (manual or automatic) | `src/App.tsx` |
| Validate input | Centralized amount/text/date validators used by every form | `src/utils/validators.ts` |
| Prevent XSS via unsafe HTML | No use of `dangerouslySetInnerHTML`, `innerHTML`, or `eval` anywhere in the codebase — verified by grep, not just by design (see below) | n/a |
| Strict CSP | `script-src 'self'; object-src 'none'` etc. via `<meta>` in `index.html`, plus a stronger header-based version in `public/_headers` for Cloudflare Pages | `index.html`, `public/_headers` |
| IndexedDB over localStorage | Small hand-written wrapper, async, structured | `src/storage/db.ts` |
| No analytics/tracking/external scripts | Zero third-party runtime dependencies besides React itself; zero `fetch`/`XMLHttpRequest`/`WebSocket` calls anywhere | verified by grep, see below |
| Never transmit data | `connect-src 'self'` in the CSP makes this a browser-enforced guarantee, not just an absence of code | `index.html` |

### Verification actually performed (not just claimed)

Before writing this document I ran greps across `src/` for:
- `dangerouslySetInnerHTML`, `innerHTML`, `outerHTML`, `document.write`, `eval(`, `new Function(` → **none found**
- `fetch(`, `XMLHttpRequest`, `WebSocket`, `sendBeacon` → **none found**
- `localStorage`, `sessionStorage` → **none found** (only in comments explaining why IndexedDB was chosen instead)
- Hardcoded secrets/keys → **none found**

If you (or a future contributor) add a feature later, re-running those
greps takes a few seconds and is worth doing before every release.

---

## Known weaknesses and tradeoffs

Nothing here is a "this app is broken" issue — they're the honest edges
of what's achievable in a client-only browser app, and you should decide
for yourself whether they're acceptable for your use case.

### 1. Your password is the entire security boundary
There's no second factor and no hardware-backed key storage (browsers
don't expose that to web apps in a portable way). PBKDF2 at 310,000
iterations meaningfully slows down offline brute-force, but it does not
make a weak password safe. The 8-character minimum enforced on setup is
a low bar — **use a genuinely long, unique passphrase.** If someone
obtains your encrypted vault file (see #4) and you used a weak or
reused password, PBKDF2 buys you time, not safety.

### 2. PBKDF2, not Argon2
You asked for Argon2 "if practical." It isn't, without adding a
dependency: the Web Crypto API (the browser-native crypto engine this
app relies on for everything else) does not implement Argon2 at all —
there's no `crypto.subtle` algorithm for it. Getting Argon2 in the
browser means shipping a WASM implementation as a dependency, which cuts
against the "minimize dependencies / minimize supply-chain surface"
goal that's also part of "production quality" for a security-sensitive
app. PBKDF2-SHA256 was chosen as the pragmatic tradeoff: it's native,
well-audited, and FIPS/NIST-recognized, at the cost of being more
GPU-parallelizable than Argon2 or scrypt. If you want to change this
later, `src/crypto/crypto.ts` is the only file that needs to change —
swap in a WASM Argon2 library, derive the key the same way, and update
`VaultRecord` to record which KDF was used (for backward compatibility
with existing vaults).

### 3. "Wipe from memory" is best-effort, not guaranteed
JavaScript has no API to force-zero memory or control garbage collection
timing. Locking the app drops every reference to the key and decrypted
data (`cryptoKeyRef.current = null`, `setData(null)`), making them
eligible for garbage collection — but the underlying bytes could
theoretically still exist in the JS engine's heap until GC actually
runs. This is a limitation of running in any managed-memory runtime
(the same is true of most browser-based password managers and crypto
tools). The non-extractable `CryptoKey` design (point below) sidesteps
part of this: the raw AES key bytes are never in a readable JS variable
in the first place, so there's nothing for a memory-scraping attack to
find for the key itself — only the decrypted *data* is subject to this
caveat, not the key.

### 4. Encryption protects the data, not the device
This app encrypts what it stores, but it doesn't encrypt your disk. The
encrypted IndexedDB file itself lives in your browser profile like any
other site data. Anyone with OS-level access to that profile (malware
running as your user, another browser extension with broad permissions,
someone with physical access to an unlocked/unencrypted computer) can
copy that file and attempt offline brute-force at their leisure, limited
only by your password strength and the PBKDF2 cost (see #1). **Turn on
full-disk encryption (BitLocker on Windows, FileVault on Mac) as a
complementary layer** — this app's encryption and your OS's disk
encryption protect against different things and you want both.

### 5. `<meta>` CSP is weaker than a real HTTP header
GitHub Pages cannot serve custom HTTP headers at all, so the CSP there
is delivered via `<meta http-equiv="Content-Security-Policy">` in
`index.html`. This has real gaps: `frame-ancestors` is silently ignored
when set via `<meta>` (per spec), meaning a malicious site could iframe
your GitHub Pages deployment for a clickjacking attempt. There's no
`Strict-Transport-Security` header either (though GitHub Pages does
force HTTPS at the platform level, so this is a smaller gap). **If this
matters to you, deploy to Cloudflare Pages instead** — `public/_headers`
sets a full header-based CSP with `frame-ancestors 'none'`,
`X-Frame-Options: DENY`, and a few other headers GitHub Pages simply
has no mechanism to send.

### 6. No stored-password verifier — offline attacks are equally possible either way
The app deliberately doesn't store a separate password hash/verifier —
wrong-password detection instead relies on AES-GCM's authentication tag
failing to verify. This wasn't done as an anti-brute-force measure
(it isn't one: the ciphertext + auth tag already serves as a perfectly
good oracle for an offline attacker to check password guesses against,
identical in cost to a dedicated verifier). It was done to keep the
vault format smaller and the crypto code simpler. Don't read "no stored
password hash" as "resistant to offline guessing" — that resistance
comes entirely from PBKDF2's iteration count (see #1 and #2).

### 7. No rate limiting on password attempts
The lock screen doesn't throttle repeated wrong-password submissions.
This wouldn't meaningfully protect against a real offline attacker
anyway (they're not limited by your UI), so it was left out rather than
adding fake security theater. It would add a small deterrent against
someone with brief physical access repeatedly guessing by hand; low
priority, but a reasonable future addition to `LockScreen.tsx`.

### 8. Data loss risk on iOS
iOS Safari can evict a site's storage — including IndexedDB — under
storage pressure or after a period of disuse, even for installed
home-screen PWAs, though installed PWAs are meaningfully more durable
than a regular Safari tab. `src/main.tsx` calls
`navigator.storage.persist()` on load to request that the browser treat
this site's storage as non-evictable, which materially reduces (but per
spec does not guarantee) this risk. There is a manual export feature
(see #9) which is the practical mitigation for this on iPhone — export
periodically rather than relying solely on `persist()`.

### 9. Manual export/import (added for cross-device use)

The **Export** button reads the encrypted `VaultRecord` straight out of
IndexedDB and downloads it as-is — nothing is decrypted to produce that
file, and nothing needs to be decrypted to validate one on import
(`parseVaultFile` in `src/utils/vaultFile.ts` only checks the shape:
salt/iv/ciphertext are strings, iterations is a positive number). This
means:

- **The exported file is exactly as safe as your IndexedDB data
  already is** — safe to put in a cloud drive folder, email to
  yourself, or carry on a USB stick, because it's still fully encrypted
  ciphertext. Whoever might see that file still needs your master
  password to read anything.
- **It's also exactly as *unsafe*** — if your master password is weak,
  the exported file is just as brute-forceable as the on-device copy.
  Moving it around doesn't add or remove risk beyond the risk of the
  transport method itself (e.g., an email account with a weak password
  is a weak link, not because of anything this app does, but because
  you'd be storing an encrypted-but-still-attackable file there).
- **Import overwrites, it doesn't merge.** Restoring a backup on a
  device that already has its own vault replaces that vault entirely
  (after an explicit confirmation step). Import an old or wrong backup
  and you will lose whatever was only on that device. There's no undo
  once confirmed — treat "which backup is newest" as your
  responsibility, since the app has no way to compare them for you
  (they're encrypted; it can't peek inside to check dates without a
  password).
- **The two vaults can end up with different master passwords.** Since
  each device sets up its own password independently the first time,
  restoring one device's backup onto another requires *that backup's*
  password, not necessarily the password you'd been using locally. This
  is expected, but easy to forget in the moment.

### 10. Supply chain is still npm-based at build time
Runtime dependencies are minimal (React and ReactDOM only — no icon
library, no crypto library, no state management library; see
`src/icons/icons.tsx` and `src/crypto/crypto.ts`, both hand-written).
But the *build tooling* — Vite, TypeScript, and `vite-plugin-pwa` (which
pulls in Workbox) — is still regular npm packages, executed on whatever
machine runs `npm install` and `npm run build` (your machine, or GitHub
Actions). This is normal for any modern web project, but it's still a
theoretical supply-chain vector. `package-lock.json` (generated on your
first `npm install`) pins exact versions — commit it, and consider
running `npm audit` periodically.

### 11. XSS protection depends on this staying true as the app grows
There is currently no unsafe HTML rendering anywhere (verified above),
and the CSP would block externally-hosted injected scripts even if that
changed. But CSP is defense-in-depth, not a substitute for care: if a
future change introduces `dangerouslySetInnerHTML` with
attacker-influenced content, or a same-origin gadget an attacker can
trigger some other way, `script-src 'self'` doesn't save you from
same-origin script execution. Re-run the grep checks above before every
release.

---

## Suggested next steps, roughly in priority order

1. Actually run the app (`npm install && npm run build && npm run preview`) and click through setup, unlock, adding/editing entries, lock, export, import/restore, and the "forgot password" reset flow before trusting it.
2. Choose a genuinely strong, unique master password — this matters more than any other item on this list.
3. Turn on full-disk encryption on whatever device you use this on.
4. If you care about the `frame-ancestors` / header gap, deploy to Cloudflare Pages instead of GitHub Pages.
5. If you rely on this on an iPhone, export a backup periodically (see #9) rather than assuming `persist()` alone protects you from storage eviction.
