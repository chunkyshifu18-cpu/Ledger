/**
 * Core data model. Everything in a `LedgerData` object is what gets
 * JSON-serialized and encrypted as a single blob before it touches disk
 * (see src/crypto/crypto.ts and src/storage/db.ts). There is no partial
 * encryption or field-level encryption — the whole thing is one AES-GCM
 * ciphertext, which keeps the crypto code small and easy to audit.
 */

export interface IncomeEntry {
  id: string;
  description: string;
  amount: number;
  date: string; // "YYYY-MM-DD"
}

export interface ExpenseEntry {
  id: string;
  description: string;
  amount: number;
  category: string;
  date: string; // "YYYY-MM-DD"
  /** True if this entry was auto-generated from a RecurringPayment template. */
  recurring?: boolean;
  /** id of the RecurringPayment that generated this entry, if any. */
  sourceId?: string;
}

export interface RecurringPayment {
  id: string;
  description: string;
  amount: number;
  category: string;
}

export interface PlannedIncome {
  id: string;
  description: string;
  amount: number;
}

export interface BudgetPlan {
  income: PlannedIncome[];
  /** category name -> planned amount for that category, this month only */
  expenses: Record<string, number>;
}

export interface MonthData {
  id: string;
  year: number;
  month: number; // 0-11
  income: IncomeEntry[];
  expenses: ExpenseEntry[];
  budgetPlan: BudgetPlan;
}

export interface LedgerData {
  months: MonthData[];
  recurring: RecurringPayment[];
  categories: string[];
}

/** A month with its running totals computed. See computeMonths() in App.tsx. */
export interface ComputedMonth extends MonthData {
  totalIncome: number;
  totalExpenses: number;
  startingBalance: number;
  netBalance: number;
}

/**
 * What's actually stored in IndexedDB. `salt` and `iterations` are
 * required to re-derive the AES key from the user's password next time;
 * neither the password nor the derived key are ever part of this record.
 */
export interface VaultRecord {
  version: 1;
  salt: string; // base64
  iterations: number;
  iv: string; // base64, unique per encryption
  ciphertext: string; // base64
}
