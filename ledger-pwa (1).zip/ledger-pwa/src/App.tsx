import { useCallback, useEffect, useRef, useState } from "react";
import type { ReactNode } from "react";
import type { LedgerData, VaultRecord } from "./types";
import { deriveKey, encryptJSON, decryptJSON, generateSalt, saltToBase64, saltFromBase64, DEFAULT_PBKDF2_ITERATIONS } from "./crypto/crypto";
import { loadVaultRecord, saveVaultRecord, deleteVaultRecord } from "./storage/db";
import { createEmptyLedger } from "./data/defaultData";
import { useInactivityLock } from "./hooks/useInactivityLock";
import { LockScreen } from "./components/LockScreen";
import { BudgetTracker } from "./components/BudgetTracker";
import { colors, bodyFont } from "./styles/theme";

/** "Automatically lock the application after 10 minutes of inactivity." */
const INACTIVITY_TIMEOUT_MS = 10 * 60 * 1000;

/** How long to wait after the last edit before re-encrypting and writing to IndexedDB. */
const SAVE_DEBOUNCE_MS = 600;

type Phase = "loading" | "setup" | "locked" | "unlocked" | "error";

export default function App() {
  const [phase, setPhase] = useState<Phase>("loading");
  const [data, setData] = useState<LedgerData | null>(null);
  const [errorMessage, setErrorMessage] = useState("");

  // The decryption key and salt live ONLY in these refs — plain
  // component state would work too, but refs make it explicit that
  // updates here are an intentional side-channel outside the render
  // cycle, not something that should ever be serialized, logged via a
  // dev tool, or accidentally included in a memoization dependency
  // array. They are never written to IndexedDB, localStorage, or
  // anywhere else. See src/crypto/crypto.ts for why the CryptoKey itself
  // can't be extracted even if this ref were somehow exposed.
  const cryptoKeyRef = useRef<CryptoKey | null>(null);
  const saltRef = useRef<Uint8Array | null>(null);
  const iterationsRef = useRef<number>(DEFAULT_PBKDF2_ITERATIONS);
  const saveTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    (async () => {
      try {
        const record = await loadVaultRecord();
        setPhase(record ? "locked" : "setup");
      } catch {
        setErrorMessage(
          "Could not access local storage. Private/incognito browsing modes sometimes block IndexedDB — try a normal browser window."
        );
        setPhase("error");
      }
    })();
  }, []);

  /**
   * Locks the app: wipes the in-memory key and decrypted data. The key
   * was created non-extractable, so this isn't "erasing secret bytes" so
   * much as "dropping the only reference to the object that could
   * decrypt anything" — once this ref is null and `data` is null, there
   * is nothing left in memory to attack.
   */
  const lock = useCallback(() => {
    if (saveTimerRef.current) clearTimeout(saveTimerRef.current);
    cryptoKeyRef.current = null;
    saltRef.current = null;
    setData(null);
    setPhase((p) => (p === "unlocked" ? "locked" : p));
  }, []);

  useInactivityLock(lock, INACTIVITY_TIMEOUT_MS, phase === "unlocked");

  // Debounced encrypted save whenever the ledger data changes while unlocked.
  useEffect(() => {
    if (phase !== "unlocked" || !data || !cryptoKeyRef.current || !saltRef.current) return;

    if (saveTimerRef.current) clearTimeout(saveTimerRef.current);
    saveTimerRef.current = setTimeout(() => {
      void (async () => {
        const key = cryptoKeyRef.current;
        const salt = saltRef.current;
        if (!key || !salt) return; // app may have locked while this timer was pending
        try {
          const { iv, ciphertext } = await encryptJSON(key, data);
          const record: VaultRecord = {
            version: 1,
            salt: saltToBase64(salt),
            iterations: iterationsRef.current,
            iv,
            ciphertext,
          };
          await saveVaultRecord(record);
        } catch (e) {
          // A save failure shouldn't crash the UI — the user's edits stay
          // in memory and will be retried on the next change. Surfacing
          // this quietly to the console is enough for a personal-use app;
          // see README for the tradeoffs of not showing a UI toast here.
          console.error("Ledger: failed to save encrypted data", e);
        }
      })();
    }, SAVE_DEBOUNCE_MS);

    return () => {
      if (saveTimerRef.current) clearTimeout(saveTimerRef.current);
    };
  }, [data, phase]);

  const handleCreateVault = async (password: string) => {
    const salt = generateSalt();
    const key = await deriveKey(password, salt, DEFAULT_PBKDF2_ITERATIONS);
    const initial = createEmptyLedger();
    const { iv, ciphertext } = await encryptJSON(key, initial);
    const record: VaultRecord = { version: 1, salt: saltToBase64(salt), iterations: DEFAULT_PBKDF2_ITERATIONS, iv, ciphertext };
    await saveVaultRecord(record);

    cryptoKeyRef.current = key;
    saltRef.current = salt;
    iterationsRef.current = DEFAULT_PBKDF2_ITERATIONS;
    setData(initial);
    setPhase("unlocked");
  };

  const handleUnlock = async (password: string) => {
    const record = await loadVaultRecord();
    if (!record) throw new Error("No vault found");

    const salt = saltFromBase64(record.salt);
    const key = await deriveKey(password, salt, record.iterations);
    // decryptJSON throws (AES-GCM auth tag mismatch) if the password is wrong.
    const decrypted = await decryptJSON<LedgerData>(key, record);

    cryptoKeyRef.current = key;
    saltRef.current = salt;
    iterationsRef.current = record.iterations;
    setData(decrypted);
    setPhase("unlocked");
  };

  const handleResetVault = async () => {
    await deleteVaultRecord();
    cryptoKeyRef.current = null;
    saltRef.current = null;
    setData(null);
    setPhase("setup");
  };

  /**
   * Restores a previously-exported vault file. This overwrites whatever
   * is currently stored locally (the caller is responsible for warning
   * about that — see LockScreen's confirm step). Nothing is decrypted
   * here: we just replace the encrypted blob and drop back to the
   * "locked" screen, since we still need the *matching* master password
   * (from whichever device the backup came from) to actually unlock it.
   */
  const handleImportVault = async (record: VaultRecord) => {
    await saveVaultRecord(record);
    cryptoKeyRef.current = null;
    saltRef.current = null;
    setData(null);
    setPhase("locked");
  };

  if (phase === "loading") {
    return <CenteredMessage>Loading…</CenteredMessage>;
  }

  if (phase === "error") {
    return <CenteredMessage tone="error">{errorMessage}</CenteredMessage>;
  }

  if (phase === "setup" || phase === "locked") {
    return (
      <LockScreen
        mode={phase}
        onCreate={handleCreateVault}
        onUnlock={handleUnlock}
        onResetVault={handleResetVault}
        onImport={handleImportVault}
      />
    );
  }

  // phase === "unlocked" — `data` is guaranteed non-null by the transitions above
  return <BudgetTracker data={data as LedgerData} onChange={setData} onLock={lock} />;
}

function CenteredMessage({ children, tone }: { children: ReactNode; tone?: "error" }) {
  return (
    <div
      style={{
        minHeight: "100vh",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        background: colors.ink,
        color: tone === "error" ? colors.rust : colors.textMuted,
        fontFamily: bodyFont,
        padding: 24,
        textAlign: "center",
      }}
    >
      {children}
    </div>
  );
}
