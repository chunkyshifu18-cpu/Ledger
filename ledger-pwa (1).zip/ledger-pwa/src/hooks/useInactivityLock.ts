import { useEffect, useRef, useCallback } from "react";

const ACTIVITY_EVENTS: (keyof WindowEventMap)[] = [
  "mousedown",
  "mousemove",
  "keydown",
  "touchstart",
  "wheel",
];

/**
 * Calls `onTimeout` after `timeoutMs` of no mouse/keyboard/touch
 * activity. Any activity resets the clock. This is the mechanism behind
 * "automatically lock the application after 10 minutes of inactivity" —
 * `onTimeout` is expected to clear the in-memory key and decrypted data
 * (see App.tsx's `lock()`).
 *
 * `enabled` should be tied to whether the app is currently unlocked —
 * there's nothing to time out while the lock screen is already showing.
 */
export function useInactivityLock(onTimeout: () => void, timeoutMs: number, enabled: boolean): void {
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const resetTimer = useCallback(() => {
    if (timerRef.current) clearTimeout(timerRef.current);
    timerRef.current = setTimeout(onTimeout, timeoutMs);
  }, [onTimeout, timeoutMs]);

  useEffect(() => {
    if (!enabled) {
      if (timerRef.current) clearTimeout(timerRef.current);
      return;
    }

    resetTimer();
    for (const event of ACTIVITY_EVENTS) {
      window.addEventListener(event, resetTimer, { passive: true });
    }

    // Also treat "tab became visible again" as activity, so switching
    // back to the app after a while doesn't leave a stale short fuse.
    const onVisibilityChange = () => {
      if (document.visibilityState === "visible") resetTimer();
    };
    document.addEventListener("visibilitychange", onVisibilityChange);

    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
      for (const event of ACTIVITY_EVENTS) {
        window.removeEventListener(event, resetTimer);
      }
      document.removeEventListener("visibilitychange", onVisibilityChange);
    };
  }, [enabled, resetTimer]);
}
