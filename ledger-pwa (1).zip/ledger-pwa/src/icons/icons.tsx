/**
 * A minimal hand-rolled icon set. Using plain inline SVG instead of an
 * icon package keeps the dependency list (and therefore the audit
 * surface / supply-chain risk) as small as possible for an app that
 * handles financial data — every dependency is something a supply-chain
 * attack could target.
 */
import type { SVGProps, ReactNode } from "react";

interface IconProps extends SVGProps<SVGSVGElement> {
  size?: number;
}

function svg(children: ReactNode) {
  return function Icon({ size = 16, color = "currentColor", ...rest }: IconProps) {
    return (
      <svg
        width={size}
        height={size}
        viewBox="0 0 24 24"
        fill="none"
        stroke={color}
        strokeWidth={2}
        strokeLinecap="round"
        strokeLinejoin="round"
        aria-hidden="true"
        {...rest}
      >
        {children}
      </svg>
    );
  };
}

export const PlusIcon = svg(
  <>
    <line x1="12" y1="5" x2="12" y2="19" />
    <line x1="5" y1="12" x2="19" y2="12" />
  </>
);

export const TrashIcon = svg(
  <>
    <polyline points="3 6 5 6 21 6" />
    <path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6" />
    <path d="M10 11v6" />
    <path d="M14 11v6" />
    <path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2" />
  </>
);

export const TrendingUpIcon = svg(
  <>
    <polyline points="23 6 13.5 15.5 8.5 10.5 1 18" />
    <polyline points="17 6 23 6 23 12" />
  </>
);

export const TrendingDownIcon = svg(
  <>
    <polyline points="23 18 13.5 8.5 8.5 13.5 1 6" />
    <polyline points="17 18 23 18 23 12" />
  </>
);

export const TargetIcon = svg(
  <>
    <circle cx="12" cy="12" r="9" />
    <circle cx="12" cy="12" r="5" />
    <circle cx="12" cy="12" r="1.5" fill="currentColor" stroke="none" />
  </>
);

export const ChevronLeftIcon = svg(<polyline points="15 18 9 12 15 6" />);
export const ChevronRightIcon = svg(<polyline points="9 18 15 12 9 6" />);

export const PencilIcon = svg(
  <path d="M17 3a2.83 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z" />
);

export const CheckIcon = svg(<polyline points="20 6 9 17 4 12" />);

export const XIcon = svg(
  <>
    <line x1="18" y1="6" x2="6" y2="18" />
    <line x1="6" y1="6" x2="18" y2="18" />
  </>
);

export const RepeatIcon = svg(
  <>
    <polyline points="17 1 21 5 17 9" />
    <path d="M3 11V9a4 4 0 0 1 4-4h14" />
    <polyline points="7 23 3 19 7 15" />
    <path d="M21 13v2a4 4 0 0 1-4 4H3" />
  </>
);

export const LockIcon = svg(
  <>
    <rect x="3" y="11" width="18" height="10" rx="2" />
    <path d="M7 11V7a5 5 0 0 1 10 0v4" />
  </>
);

export const DownloadIcon = svg(
  <>
    <path d="M12 3v12" />
    <polyline points="7 10 12 15 17 10" />
    <path d="M5 19h14" />
  </>
);

export const ArrowRightIcon = svg(
  <>
    <line x1="5" y1="12" x2="19" y2="12" />
    <polyline points="12 5 19 12 12 19" />
  </>
);
