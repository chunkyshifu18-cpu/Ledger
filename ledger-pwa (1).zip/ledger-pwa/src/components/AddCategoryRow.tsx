import { useState } from "react";
import { PlusIcon } from "../icons/icons";
import { inputStyle, colors } from "../styles/theme";
import { sanitizeText } from "../utils/validators";

interface AddCategoryRowProps {
  onAdd: (name: string) => void;
}

export function AddCategoryRow({ onAdd }: AddCategoryRowProps) {
  const [name, setName] = useState("");

  const submit = () => {
    const cleaned = sanitizeText(name, 40);
    if (!cleaned) return;
    onAdd(cleaned);
    setName("");
  };

  return (
    <div style={{ display: "flex", gap: 8, marginBottom: 16 }}>
      <input
        type="text"
        placeholder="New category name (e.g. Rent)"
        value={name}
        onChange={(e) => setName(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === "Enter") {
            e.preventDefault();
            submit();
          }
        }}
        style={{ ...inputStyle, flex: 1 }}
      />
      <button
        type="button"
        onClick={submit}
        style={{
          background: colors.inkPanel,
          border: `1px solid ${colors.inkInputBorder}`,
          borderRadius: 6,
          color: colors.gold,
          fontWeight: 700,
          padding: "8px 14px",
          fontSize: 13,
          display: "flex",
          alignItems: "center",
          gap: 6,
          cursor: "pointer",
        }}
      >
        <PlusIcon size={14} /> Add category
      </button>
    </div>
  );
}
