import { useEffect, useMemo, useRef, useState } from "react";
import type { LedgerData, MonthData, RecurringPayment, ComputedMonth, ExpenseEntry } from "../types";
import { uid } from "../utils/id";
import { fmt, monthLabel, nextYearMonth, firstOfMonthStr, todayStr, RECEIPT_TEETH_CLIP_PATH } from "../utils/format";
import { parseValidAmount, parseValidAmountOrZero, sanitizeText } from "../utils/validators";
import { colors, monoFont, bodyFont, sectionHeadingStyle, inputStyle } from "../styles/theme";
import { AddRow } from "./AddRow";
import { EntryList } from "./EntryList";
import { MonthNav } from "./MonthNav";
import { AddCategoryRow } from "./AddCategoryRow";
import { loadVaultRecord } from "../storage/db";
import { downloadVaultRecord } from "../utils/vaultFile";
import {
  PlusIcon,
  TrashIcon,
  TrendingUpIcon,
  TrendingDownIcon,
  TargetIcon,
  ArrowRightIcon,
  RepeatIcon,
  LockIcon,
  DownloadIcon,
} from "../icons/icons";

interface BudgetTrackerProps {
  data: LedgerData;
  onChange: (data: LedgerData) => void;
  onLock: () => void;
}

type Tab = "months" | "recurring" | "budget";

function cloneRecurringToExpense(template: RecurringPayment, year: number, month: number): ExpenseEntry {
  return {
    id: uid(),
    description: template.description,
    amount: template.amount,
    category: template.category,
    date: firstOfMonthStr(year, month),
    recurring: true,
    sourceId: template.id,
  };
}

function computeMonths(months: MonthData[]): ComputedMonth[] {
  let running = 0;
  return months.map((m) => {
    const totalIncome = m.income.reduce((s, i) => s + i.amount, 0);
    const totalExpenses = m.expenses.reduce((s, e) => s + e.amount, 0);
    const startingBalance = running;
    const netBalance = startingBalance + totalIncome - totalExpenses;
    running = netBalance;
    return { ...m, totalIncome, totalExpenses, startingBalance, netBalance };
  });
}

export function BudgetTracker({ data, onChange, onLock }: BudgetTrackerProps) {
  const [months, setMonths] = useState<MonthData[]>(data.months);
  const [recurring, setRecurring] = useState<RecurringPayment[]>(data.recurring);
  const [categories, setCategories] = useState<string[]>(data.categories);
  const [monthIndex, setMonthIndex] = useState<number>(Math.max(0, data.months.length - 1));
  const [tab, setTab] = useState<Tab>("months");
  const [confirmDeleteMonth, setConfirmDeleteMonth] = useState(false);
  const [exportError, setExportError] = useState("");

  const handleExport = async () => {
    setExportError("");
    try {
      // Reads the encrypted record directly from IndexedDB — nothing is
      // decrypted for this. The downloaded file is exactly as safe (or
      // unsafe) as what's already sitting on this device.
      const record = await loadVaultRecord();
      if (!record) {
        setExportError("Nothing to export yet.");
        return;
      }
      downloadVaultRecord(record);
    } catch {
      setExportError("Could not export a backup. Try again.");
    }
  };

  // Report changes upward (App.tsx encrypts + persists them). Skipped on
  // the very first render since that would just re-save identical data.
  const isFirstRender = useRef(true);
  useEffect(() => {
    if (isFirstRender.current) {
      isFirstRender.current = false;
      return;
    }
    onChange({ months, recurring, categories });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [months, recurring, categories]);

  // Keep every month in sync with the recurring payments list — catches
  // items added while no month was "active", or added before a later
  // month existed.
  useEffect(() => {
    setMonths((prev) =>
      prev.map((m) => {
        const missing = recurring.filter((r) => !m.expenses.some((e) => e.sourceId === r.id));
        if (missing.length === 0) return m;
        return { ...m, expenses: [...m.expenses, ...missing.map((r) => cloneRecurringToExpense(r, m.year, m.month))] };
      })
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [recurring]);

  const computedMonths = useMemo(() => computeMonths(months), [months]);
  const safeIndex = Math.min(Math.max(monthIndex, 0), Math.max(computedMonths.length - 1, 0));
  const activeMonth = computedMonths[safeIndex]!; // months always has >= 1 entry, enforced by deleteMonth guard

  const addMonth = () => {
    const last = months[months.length - 1];
    const { year, month } = last
      ? nextYearMonth(last.year, last.month)
      : (() => {
          const n = new Date();
          return { year: n.getFullYear(), month: n.getMonth() };
        })();
    const seededExpenses = recurring.map((r) => cloneRecurringToExpense(r, year, month));
    const carriedPlan = last
      ? { income: last.budgetPlan.income.map((i) => ({ ...i, id: uid() })), expenses: { ...last.budgetPlan.expenses } }
      : { income: [], expenses: {} };
    const newMonth: MonthData = { id: uid(), year, month, income: [], expenses: seededExpenses, budgetPlan: carriedPlan };
    setMonths((s) => [...s, newMonth]);
    setMonthIndex(months.length);
    setTab("months");
  };

  const deleteMonth = () => {
    if (months.length <= 1) {
      setConfirmDeleteMonth(false);
      return;
    }
    const idToDelete = activeMonth.id;
    setMonths((prev) => prev.filter((m) => m.id !== idToDelete));
    setMonthIndex((i) => Math.max(0, Math.min(i, months.length - 2)));
    setConfirmDeleteMonth(false);
  };

  const updateMonth = (id: string, fn: (m: MonthData) => MonthData) =>
    setMonths((s) => s.map((m) => (m.id === id ? fn(m) : m)));

  const addIncome = (monthId: string, v: Record<string, string>) =>
    updateMonth(monthId, (m) => ({
      ...m,
      income: [
        ...m.income,
        { id: uid(), description: sanitizeText(v.description ?? ""), amount: parseValidAmount(v.amount ?? "") ?? 0, date: v.date || todayStr() },
      ],
    }));

  const addExpense = (monthId: string, v: Record<string, string>) =>
    updateMonth(monthId, (m) => ({
      ...m,
      expenses: [
        ...m.expenses,
        {
          id: uid(),
          description: sanitizeText(v.description ?? ""),
          amount: parseValidAmount(v.amount ?? "") ?? 0,
          category: v.category ?? categories[0] ?? "Other",
          date: v.date || todayStr(),
        },
      ],
    }));

  const deleteIncome = (monthId: string, id: string) => updateMonth(monthId, (m) => ({ ...m, income: m.income.filter((i) => i.id !== id) }));
  const deleteExpense = (monthId: string, id: string) => updateMonth(monthId, (m) => ({ ...m, expenses: m.expenses.filter((e) => e.id !== id) }));

  const editIncome = (monthId: string, id: string, update: { description: string; amount: number; date: string }) =>
    updateMonth(monthId, (m) => ({ ...m, income: m.income.map((i) => (i.id === id ? { ...i, ...update } : i)) }));

  const editExpense = (monthId: string, id: string, update: { description: string; amount: number; date: string; category?: string }) =>
    updateMonth(monthId, (m) => ({
      ...m,
      expenses: m.expenses.map((e) => (e.id === id ? { ...e, ...update, category: update.category ?? e.category } : e)),
    }));

  const addRecurring = (v: Record<string, string>) => {
    const template: RecurringPayment = {
      id: uid(),
      description: sanitizeText(v.description ?? ""),
      amount: parseValidAmount(v.amount ?? "") ?? 0,
      category: v.category ?? categories[0] ?? "Other",
    };
    setRecurring((s) => [...s, template]);
  };
  const deleteRecurring = (id: string) => setRecurring((s) => s.filter((r) => r.id !== id));

  const addPlannedIncome = (v: Record<string, string>) =>
    updateMonth(activeMonth.id, (m) => ({
      ...m,
      budgetPlan: {
        ...m.budgetPlan,
        income: [...m.budgetPlan.income, { id: uid(), description: sanitizeText(v.description ?? ""), amount: parseValidAmount(v.amount ?? "") ?? 0 }],
      },
    }));
  const deletePlannedIncome = (id: string) =>
    updateMonth(activeMonth.id, (m) => ({ ...m, budgetPlan: { ...m.budgetPlan, income: m.budgetPlan.income.filter((i) => i.id !== id) } }));
  const setPlannedExpense = (category: string, amount: string) =>
    updateMonth(activeMonth.id, (m) => ({ ...m, budgetPlan: { ...m.budgetPlan, expenses: { ...m.budgetPlan.expenses, [category]: parseValidAmountOrZero(amount) } } }));

  const addCategory = (name: string) => {
    if (categories.some((c) => c.toLowerCase() === name.toLowerCase())) return;
    setCategories((s) => [...s, name]);
  };
  const deleteCategory = (name: string) => {
    if (categories.length <= 1) return;
    setCategories((s) => s.filter((c) => c !== name));
    setMonths((prev) =>
      prev.map((m) => {
        const rest = { ...m.budgetPlan.expenses };
        delete rest[name];
        return { ...m, budgetPlan: { ...m.budgetPlan, expenses: rest } };
      })
    );
  };

  const plannedIncomeTotal = useMemo(() => activeMonth.budgetPlan.income.reduce((s, i) => s + i.amount, 0), [activeMonth]);
  const plannedExpenseTotal = useMemo(() => Object.values(activeMonth.budgetPlan.expenses).reduce((s, v) => s + (v || 0), 0), [activeMonth]);

  const categoryTotals = useMemo(() => {
    const map: Record<string, number> = {};
    for (const [category, planned] of Object.entries(activeMonth.budgetPlan.expenses)) {
      if (planned > 0) map[category] = 0;
    }
    for (const e of activeMonth.expenses) {
      map[e.category] = (map[e.category] ?? 0) + e.amount;
    }
    return Object.entries(map)
      .map(([category, total]) => ({ category, total, planned: activeMonth.budgetPlan.expenses[category] ?? 0 }))
      .sort((a, b) => b.total - a.total);
  }, [activeMonth]);

  const incomeDelta = activeMonth.totalIncome - plannedIncomeTotal;
  const expenseDelta = activeMonth.totalExpenses - plannedExpenseTotal;
  const monthNavProps = {
    label: monthLabel(activeMonth.year, activeMonth.month),
    onPrev: () => setMonthIndex((i) => Math.max(0, i - 1)),
    onNext: () => setMonthIndex((i) => Math.min(computedMonths.length - 1, i + 1)),
    disablePrev: safeIndex === 0,
    disableNext: safeIndex === computedMonths.length - 1,
  };

  return (
    <div style={{ background: colors.ink, minHeight: "100vh", fontFamily: bodyFont, color: colors.text, padding: "32px 16px 96px", position: "relative" }}>
      <div style={{ maxWidth: 640, margin: "0 auto" }}>
        <header style={{ marginBottom: 28, display: "flex", alignItems: "flex-start", justifyContent: "space-between" }}>
          <div>
            <h1 style={{ margin: 0, fontSize: 22, fontFamily: monoFont, letterSpacing: "0.04em", color: colors.gold }}>LEDGER</h1>
            <p style={{ margin: "4px 0 0", fontSize: 13, color: colors.textFaint }}>Your budget, kept like the books.</p>
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            <button
              onClick={() => void handleExport()}
              title="Download an encrypted backup file (to sync via a cloud drive folder, email it to yourself, etc.)"
              style={{ background: colors.inkPanel, border: `1px solid ${colors.inkInputBorder}`, borderRadius: 6, color: colors.textMuted, padding: "6px 10px", fontSize: 12, display: "flex", alignItems: "center", gap: 6, cursor: "pointer" }}
            >
              <DownloadIcon size={13} /> Export
            </button>
            <button
              onClick={onLock}
              title="Lock now (auto-locks after 10 minutes idle)"
              style={{ background: colors.inkPanel, border: `1px solid ${colors.inkInputBorder}`, borderRadius: 6, color: colors.textMuted, padding: "6px 10px", fontSize: 12, display: "flex", alignItems: "center", gap: 6, cursor: "pointer" }}
            >
              <LockIcon size={13} /> Lock
            </button>
          </div>
        </header>

        {exportError && <p style={{ color: colors.rust, fontSize: 12, marginTop: -18, marginBottom: 20, textAlign: "right" }}>{exportError}</p>}

        <div style={{ display: "flex", gap: 4, marginBottom: 20, borderBottom: `1px solid ${colors.inkBorder}` }}>
          {(
            [
              { key: "months", label: "Months", icon: <TrendingUpIcon size={14} /> },
              { key: "recurring", label: "Recurring", icon: <RepeatIcon size={14} /> },
              { key: "budget", label: "Budget plan", icon: <TargetIcon size={14} /> },
            ] as const
          ).map((t) => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              style={{
                background: "none",
                border: "none",
                borderBottom: tab === t.key ? `2px solid ${colors.gold}` : "2px solid transparent",
                color: tab === t.key ? colors.gold : colors.textMuted,
                padding: "8px 12px",
                fontSize: 13,
                fontFamily: monoFont,
                letterSpacing: "0.04em",
                textTransform: "uppercase",
                display: "flex",
                alignItems: "center",
                gap: 6,
                cursor: "pointer",
              }}
            >
              {t.icon} {t.label}
            </button>
          ))}
        </div>

        {tab === "months" && (
          <>
            <MonthNav {...monthNavProps} />

            <div style={{ textAlign: "center", marginBottom: 18 }}>
              {!confirmDeleteMonth ? (
                <button
                  onClick={() => setConfirmDeleteMonth(true)}
                  disabled={months.length <= 1}
                  style={{ background: "none", border: "none", color: months.length <= 1 ? colors.textDisabled : colors.textFaint, fontSize: 11, cursor: months.length <= 1 ? "default" : "pointer", display: "inline-flex", alignItems: "center", gap: 4 }}
                >
                  <TrashIcon size={11} /> Delete this month
                </button>
              ) : (
                <span style={{ fontSize: 12, color: colors.rust, display: "inline-flex", alignItems: "center", gap: 10, flexWrap: "wrap", justifyContent: "center" }}>
                  Delete {monthLabel(activeMonth.year, activeMonth.month)}? This can't be undone.
                  <button onClick={deleteMonth} style={{ background: colors.rust, border: "none", borderRadius: 4, color: colors.text, padding: "4px 10px", fontSize: 11, cursor: "pointer" }}>
                    Delete
                  </button>
                  <button onClick={() => setConfirmDeleteMonth(false)} style={{ background: "none", border: `1px solid ${colors.textDisabled}`, borderRadius: 4, color: colors.textMuted, padding: "4px 10px", fontSize: 11, cursor: "pointer" }}>
                    Cancel
                  </button>
                </span>
              )}
            </div>

            <div
              style={{
                background: colors.paper,
                color: colors.ink,
                padding: "22px 24px 30px",
                transform: "rotate(-0.6deg)",
                boxShadow: "0 12px 24px rgba(0,0,0,0.35)",
                clipPath: RECEIPT_TEETH_CLIP_PATH,
                marginBottom: 36,
              }}
            >
              <div style={{ fontFamily: monoFont, fontSize: 11, letterSpacing: "0.1em", color: colors.paperMuted, textTransform: "uppercase", marginBottom: 14, textAlign: "center", borderBottom: `1px dashed ${colors.paperBorder}`, paddingBottom: 10 }}>
                {monthLabel(activeMonth.year, activeMonth.month)}
              </div>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "6px 0", fontFamily: monoFont, fontSize: 13, color: colors.paperMuted }}>
                <span style={{ display: "flex", alignItems: "center", gap: 6 }}>
                  <ArrowRightIcon size={12} /> Starting balance
                </span>
                <span style={{ fontVariantNumeric: "tabular-nums" }}>{fmt(activeMonth.startingBalance)}</span>
              </div>
              {[
                { label: "Income", value: activeMonth.totalIncome, planned: plannedIncomeTotal, delta: incomeDelta, goodWhenPositive: true, icon: <TrendingUpIcon size={13} />, color: colors.forest },
                { label: "Expenses", value: -activeMonth.totalExpenses, planned: plannedExpenseTotal, delta: expenseDelta, goodWhenPositive: false, icon: <TrendingDownIcon size={13} />, color: colors.rust },
              ].map((row) => (
                <div key={row.label} style={{ padding: "6px 0" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", fontFamily: monoFont, fontSize: 14 }}>
                    <span style={{ display: "flex", alignItems: "center", gap: 6, color: row.color }}>
                      {row.icon} {row.label}
                    </span>
                    <span style={{ fontVariantNumeric: "tabular-nums" }}>{row.value < 0 ? `-${fmt(Math.abs(row.value))}` : fmt(row.value)}</span>
                  </div>
                  {row.planned > 0 && (
                    <div style={{ textAlign: "right", fontSize: 10, color: row.delta > 0 === row.goodWhenPositive ? colors.forest : colors.rust, fontFamily: monoFont }}>
                      planned {fmt(row.planned)} · {row.delta === 0 ? "on plan" : `${row.delta > 0 ? "+" : "-"}${fmt(Math.abs(row.delta))} ${row.delta > 0 === row.goodWhenPositive ? "ahead" : "off plan"}`}
                    </div>
                  )}
                </div>
              ))}
              <div style={{ borderTop: `1px dashed ${colors.paperBorder}`, marginTop: 10, paddingTop: 10, display: "flex", justifyContent: "space-between", fontFamily: monoFont, fontSize: 16, fontWeight: 700 }}>
                <span>Net balance</span>
                <span style={{ color: activeMonth.netBalance >= 0 ? colors.forest : colors.rust, fontVariantNumeric: "tabular-nums" }}>{fmt(activeMonth.netBalance)}</span>
              </div>
            </div>

            <div style={{ display: "flex", flexDirection: "column", gap: 32 }}>
              <div>
                <div style={sectionHeadingStyle}>Income</div>
                <AddRow
                  submitLabel="Add"
                  fields={[
                    { key: "description", label: "Source", kind: "text", placeholder: "Paycheck", required: true },
                    { key: "amount", label: "Amount", kind: "amount", placeholder: "0.00" },
                    { key: "date", label: "Date", kind: "date", defaultValue: todayStr() },
                  ]}
                  onAdd={(v) => addIncome(activeMonth.id, v)}
                />
                <EntryList
                  items={activeMonth.income}
                  onDelete={(id) => deleteIncome(activeMonth.id, id)}
                  onUpdate={(id, update) => editIncome(activeMonth.id, id, update)}
                />
              </div>

              <div>
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }}>
                  <div style={sectionHeadingStyle}>Expenses</div>
                  {recurring.length > 0 && (
                    <span style={{ fontSize: 11, color: colors.textFaint, display: "flex", alignItems: "center", gap: 4 }}>
                      <RepeatIcon size={11} color={colors.gold} /> {recurring.length} recurring set up
                    </span>
                  )}
                </div>
                <AddRow
                  submitLabel="Add"
                  fields={[
                    { key: "description", label: "Item", kind: "text", placeholder: "Groceries", required: true },
                    { key: "amount", label: "Amount", kind: "amount", placeholder: "0.00" },
                    { key: "category", label: "Category", kind: "select", options: categories, defaultValue: categories[0] },
                    { key: "date", label: "Date", kind: "date", defaultValue: todayStr() },
                  ]}
                  onAdd={(v) => addExpense(activeMonth.id, v)}
                />
                <EntryList
                  items={activeMonth.expenses}
                  onDelete={(id) => deleteExpense(activeMonth.id, id)}
                  onUpdate={(id, update) => editExpense(activeMonth.id, id, update)}
                  showCategory
                  categories={categories}
                />

                {categoryTotals.length > 0 && (
                  <div style={{ marginTop: 24 }}>
                    <div style={sectionHeadingStyle}>By category — actual vs planned</div>
                    {categoryTotals.map((c) => {
                      const scaleMax = Math.max(c.total, c.planned, 1) * 1.15;
                      const actualPct = (c.total / scaleMax) * 100;
                      const plannedPct = c.planned > 0 ? (c.planned / scaleMax) * 100 : null;
                      const overBudget = c.planned > 0 && c.total > c.planned;
                      return (
                        <div key={c.category} style={{ marginBottom: 12 }}>
                          <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, marginBottom: 4, color: colors.textMuted }}>
                            <span>{c.category}</span>
                            <span style={{ fontFamily: monoFont, fontVariantNumeric: "tabular-nums" }}>
                              {fmt(c.total)}
                              {c.planned > 0 ? ` / ${fmt(c.planned)}` : ""}
                            </span>
                          </div>
                          <div style={{ position: "relative", height: 6, background: colors.inkPanel, borderRadius: 3 }}>
                            <div style={{ height: "100%", width: `${actualPct}%`, background: overBudget ? colors.rust : colors.forest, borderRadius: 3 }} />
                            {plannedPct !== null && (
                              <div style={{ position: "absolute", top: -2, left: `${plannedPct}%`, width: 2, height: 10, background: colors.gold, borderRadius: 1 }} title="Planned budget" />
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          </>
        )}

        {tab === "recurring" && (
          <section>
            <p style={{ fontSize: 13, color: colors.textMuted, marginTop: 0, marginBottom: 18 }}>
              Set up payments that happen every month, like rent or insurance. Each one is added automatically to every month.
            </p>
            <AddRow
              submitLabel="Add recurring payment"
              fields={[
                { key: "description", label: "Payment", kind: "text", placeholder: "Rent", required: true },
                { key: "amount", label: "Amount", kind: "amount", placeholder: "0.00" },
                { key: "category", label: "Category", kind: "select", options: categories, defaultValue: categories[0] },
              ]}
              onAdd={addRecurring}
            />
            {recurring.length === 0 ? (
              <p style={{ color: colors.textFaint, fontSize: 13, fontStyle: "italic" }}>No recurring payments yet — add one above.</p>
            ) : (
              <div style={{ display: "flex", flexDirection: "column" }}>
                {recurring.map((r, i) => (
                  <div key={r.id} style={{ display: "flex", alignItems: "center", gap: 10, padding: "9px 4px", background: i % 2 === 0 ? "rgba(255,255,255,0.02)" : "transparent", borderBottom: `1px solid ${colors.inkBorder}` }}>
                    <RepeatIcon size={13} color={colors.gold} />
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontSize: 14, color: colors.text }}>{r.description}</div>
                      <div style={{ fontSize: 11, color: colors.textFaint, fontFamily: monoFont }}>{r.category} · every month</div>
                    </div>
                    <div style={{ fontFamily: monoFont, fontSize: 14, color: colors.text, fontVariantNumeric: "tabular-nums" }}>{fmt(r.amount)}</div>
                    <button onClick={() => deleteRecurring(r.id)} aria-label="Delete recurring payment" style={{ background: "none", border: "none", color: colors.textFaint, cursor: "pointer", padding: 4, display: "flex" }}>
                      <TrashIcon size={15} />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </section>
        )}

        {tab === "budget" && (
          <section>
            <MonthNav {...monthNavProps} />
            <p style={{ fontSize: 13, color: colors.textMuted, marginTop: 0, marginBottom: 18, textAlign: "center" }}>
              This plan is just for <strong>{monthLabel(activeMonth.year, activeMonth.month)}</strong>. New months carry it forward
              automatically, but you can adjust any month on its own.
            </p>

            <div style={{ marginBottom: 32 }}>
              <div style={sectionHeadingStyle}>Planned income — {fmt(plannedIncomeTotal)} total</div>
              <AddRow
                submitLabel="Add"
                fields={[
                  { key: "description", label: "Source", kind: "text", placeholder: "Paycheck", required: true },
                  { key: "amount", label: "Amount", kind: "amount", placeholder: "0.00" },
                ]}
                onAdd={addPlannedIncome}
              />
              {activeMonth.budgetPlan.income.length === 0 ? (
                <p style={{ color: colors.textFaint, fontSize: 13, fontStyle: "italic" }}>No planned income yet — add one above.</p>
              ) : (
                <div style={{ display: "flex", flexDirection: "column" }}>
                  {activeMonth.budgetPlan.income.map((i, idx) => (
                    <div key={i.id} style={{ display: "flex", alignItems: "center", gap: 10, padding: "9px 4px", background: idx % 2 === 0 ? "rgba(255,255,255,0.02)" : "transparent", borderBottom: `1px solid ${colors.inkBorder}` }}>
                      <div style={{ flex: 1, fontSize: 14 }}>{i.description}</div>
                      <div style={{ fontFamily: monoFont, fontSize: 14, fontVariantNumeric: "tabular-nums" }}>{fmt(i.amount)}</div>
                      <button onClick={() => deletePlannedIncome(i.id)} style={{ background: "none", border: "none", color: colors.textFaint, cursor: "pointer", padding: 4, display: "flex" }}>
                        <TrashIcon size={15} />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div>
              <div style={sectionHeadingStyle}>Planned expenses by category — {fmt(plannedExpenseTotal)} total</div>
              <AddCategoryRow onAdd={addCategory} />
              <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                {categories.map((c) => (
                  <div key={c} style={{ display: "flex", alignItems: "center", gap: 10 }}>
                    <span style={{ flex: 1, fontSize: 14 }}>{c}</span>
                    <input
                      type="number"
                      min="0"
                      step="0.01"
                      placeholder="0.00"
                      value={activeMonth.budgetPlan.expenses[c] ?? ""}
                      onChange={(e) => setPlannedExpense(c, e.target.value)}
                      style={{ ...inputStyle, width: 110 }}
                    />
                    <button
                      onClick={() => deleteCategory(c)}
                      disabled={categories.length <= 1}
                      aria-label={`Remove ${c} category`}
                      style={{ background: "none", border: "none", color: categories.length <= 1 ? colors.inkInputBorder : colors.textFaint, cursor: categories.length <= 1 ? "default" : "pointer", padding: 4, display: "flex" }}
                    >
                      <TrashIcon size={14} />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </section>
        )}
      </div>

      <button
        onClick={addMonth}
        aria-label="Add next month"
        title="Add next month"
        style={{
          position: "fixed",
          bottom: 24,
          right: 24,
          width: 52,
          height: 52,
          borderRadius: "50%",
          background: colors.gold,
          border: "none",
          color: colors.ink,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          cursor: "pointer",
          boxShadow: "0 6px 16px rgba(0,0,0,0.4)",
        }}
      >
        <PlusIcon size={24} />
      </button>
    </div>
  );
}
