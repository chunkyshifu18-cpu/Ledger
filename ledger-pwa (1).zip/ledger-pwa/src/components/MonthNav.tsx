import type { CSSProperties } from "react";
import { ChevronLeftIcon, ChevronRightIcon } from "../icons/icons";
import { colors, monoFont } from "../styles/theme";

interface MonthNavProps {
  label: string;
  onPrev: () => void;
  onNext: () => void;
  disablePrev: boolean;
  disableNext: boolean;
}

export function MonthNav({ label, onPrev, onNext, disablePrev, disableNext }: MonthNavProps) {
  return (
    <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 16, marginBottom: 18 }}>
      <button onClick={onPrev} disabled={disablePrev} aria-label="Previous month" style={navButtonStyle(disablePrev)}>
        <ChevronLeftIcon size={18} />
      </button>
      <span style={{ fontFamily: monoFont, fontSize: 15, letterSpacing: "0.03em", minWidth: 170, textAlign: "center" }}>{label}</span>
      <button onClick={onNext} disabled={disableNext} aria-label="Next month" style={navButtonStyle(disableNext)}>
        <ChevronRightIcon size={18} />
      </button>
    </div>
  );
}

function navButtonStyle(disabled: boolean): CSSProperties {
  return {
    background: colors.inkPanel,
    border: "none",
    borderRadius: "50%",
    width: 32,
    height: 32,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    color: disabled ? colors.textDisabled : colors.text,
    cursor: disabled ? "default" : "pointer",
  };
}
