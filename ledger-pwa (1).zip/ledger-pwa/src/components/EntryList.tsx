import { useState } from "react";
import type { CSSProperties } from "react";
import { TrashIcon, PencilIcon, CheckIcon, XIcon, RepeatIcon } from "../icons/icons";
import { smallInputStyle, colors, monoFont } from "../styles/theme";
import { fmt } from "../utils/format";
import { parseValidAmount, sanitizeText, isValidDateString } from "../utils/validators";

export interface EntryListItem {
  id: string;
  description: string;
  amount: number;
  date: string;
  category?: string;
  recurring?: boolean;
}

export interface EntryUpdate {
  description: string;
  amount: number;
  date: string;
  category?: string;
}

interface EntryListProps {
  items: EntryListItem[];
  onDelete: (id: string) => void;
  onUpdate: (id: string, update: EntryUpdate) => void;
  showCategory?: boolean;
  categories?: string[];
}

interface DraftState {
  description: string;
  amount: string;
  date: string;
  category: string;
}

export function EntryList({ items, onDelete, onUpdate, showCategory = false, categories = [] }: EntryListProps) {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [draft, setDraft] = useState<DraftState>({ description: "", amount: "", date: "", category: "" });

  if (items.length === 0) {
    return <p style={{ color: colors.textFaint, fontSize: 13, fontStyle: "italic" }}>No entries yet — add one above.</p>;
  }

  const startEdit = (item: EntryListItem) => {
    setEditingId(item.id);
    setDraft({
      description: item.description,
      amount: String(item.amount),
      date: item.date,
      category: item.category ?? "",
    });
  };

  const cancelEdit = () => setEditingId(null);

  const saveEdit = () => {
    const amount = parseValidAmount(draft.amount);
    const description = sanitizeText(draft.description);
    if (!description || amount === null || !isValidDateString(draft.date)) return;
    if (editingId) {
      onUpdate(editingId, { description, amount, date: draft.date, category: draft.category || undefined });
    }
    setEditingId(null);
  };

  const sorted = [...items].sort((a, b) => b.date.localeCompare(a.date));

  return (
    <div style={{ display: "flex", flexDirection: "column" }}>
      {sorted.map((item, i) => {
        const isEditing = editingId === item.id;
        return (
          <div
            key={item.id}
            style={{
              display: "flex",
              alignItems: "center",
              gap: 10,
              padding: "9px 4px",
              background: i % 2 === 0 ? "rgba(255,255,255,0.02)" : "transparent",
              borderBottom: `1px solid ${colors.inkBorder}`,
            }}
          >
            {isEditing ? (
              <>
                <input
                  style={{ ...smallInputStyle, flex: 1, minWidth: 90 }}
                  value={draft.description}
                  onChange={(e) => setDraft((d) => ({ ...d, description: e.target.value }))}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") saveEdit();
                    if (e.key === "Escape") cancelEdit();
                  }}
                />
                {showCategory && (
                  <select
                    style={{ ...smallInputStyle, width: 120 }}
                    value={draft.category}
                    onChange={(e) => setDraft((d) => ({ ...d, category: e.target.value }))}
                  >
                    {categories.map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                )}
                <input
                  type="date"
                  style={{ ...smallInputStyle, width: 130 }}
                  value={draft.date}
                  onChange={(e) => setDraft((d) => ({ ...d, date: e.target.value }))}
                />
                <input
                  type="number"
                  min="0"
                  step="0.01"
                  style={{ ...smallInputStyle, width: 80 }}
                  value={draft.amount}
                  onChange={(e) => setDraft((d) => ({ ...d, amount: e.target.value }))}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") saveEdit();
                    if (e.key === "Escape") cancelEdit();
                  }}
                />
                <button onClick={saveEdit} aria-label="Save" style={iconButtonStyle(colors.forest)}>
                  <CheckIcon size={16} />
                </button>
                <button onClick={cancelEdit} aria-label="Cancel" style={iconButtonStyle(colors.textFaint)}>
                  <XIcon size={16} />
                </button>
              </>
            ) : (
              <>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 14, color: colors.text, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", display: "flex", alignItems: "center", gap: 6 }}>
                    {item.recurring && <RepeatIcon size={12} color={colors.gold} aria-label="Recurring payment" />}
                    {item.description}
                  </div>
                  <div style={{ fontSize: 11, color: colors.textFaint, fontFamily: monoFont }}>
                    {item.date}
                    {showCategory && item.category ? ` · ${item.category}` : ""}
                  </div>
                </div>
                <div style={{ fontFamily: monoFont, fontSize: 14, color: colors.text, fontVariantNumeric: "tabular-nums" }}>{fmt(item.amount)}</div>
                <button onClick={() => startEdit(item)} aria-label="Edit entry" style={iconButtonStyle(colors.textFaint)}>
                  <PencilIcon size={14} />
                </button>
                <button onClick={() => onDelete(item.id)} aria-label="Delete entry" style={iconButtonStyle(colors.textFaint)}>
                  <TrashIcon size={15} />
                </button>
              </>
            )}
          </div>
        );
      })}
    </div>
  );
}

function iconButtonStyle(color: string): CSSProperties {
  return { background: "none", border: "none", color, cursor: "pointer", padding: 4, display: "flex" };
}
