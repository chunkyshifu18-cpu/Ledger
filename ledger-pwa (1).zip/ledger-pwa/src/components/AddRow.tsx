import { useState } from "react";
import type { KeyboardEvent } from "react";
import { PlusIcon } from "../icons/icons";
import { inputStyle, labelStyle, colors, monoFont } from "../styles/theme";
import { parseValidAmount } from "../utils/validators";

export interface AddRowField {
  key: string;
  label: string;
  kind: "text" | "amount" | "date" | "select";
  placeholder?: string;
  required?: boolean; // only meaningful for "text"
  options?: string[]; // only meaningful for "select"
  defaultValue?: string;
}

interface AddRowProps {
  fields: AddRowField[];
  submitLabel: string;
  onAdd: (values: Record<string, string>) => void;
}

function initialValues(fields: AddRowField[]): Record<string, string> {
  return Object.fromEntries(fields.map((f) => [f.key, f.defaultValue ?? ""]));
}

export function AddRow({ fields, submitLabel, onAdd }: AddRowProps) {
  const [values, setValues] = useState<Record<string, string>>(() => initialValues(fields));
  const [error, setError] = useState("");

  const setValue = (key: string, value: string) => {
    setValues((v) => ({ ...v, [key]: value }));
    if (error) setError("");
  };

  const submit = () => {
    for (const field of fields) {
      const value = values[field.key] ?? "";
      if (field.kind === "text" && field.required && !value.trim()) {
        setError(`Enter a ${field.label.toLowerCase()}.`);
        return;
      }
      if (field.kind === "amount" && parseValidAmount(value) === null) {
        setError(`Enter a ${field.label.toLowerCase()} greater than 0.`);
        return;
      }
    }
    onAdd(values);
    setValues(initialValues(fields));
    setError("");
  };

  const handleKeyDown = (e: KeyboardEvent) => {
    if (e.key === "Enter") {
      e.preventDefault();
      submit();
    }
  };

  return (
    <div style={{ marginBottom: 20 }}>
      <div style={{ display: "flex", gap: 10, flexWrap: "wrap", alignItems: "flex-end" }}>
        {fields.map((field) => (
          <label
            key={field.key}
            style={{ display: "flex", flexDirection: "column", gap: 4, fontSize: 12, color: colors.textMuted, flex: 1, minWidth: 100 }}
          >
            <span style={labelStyle}>{field.label}</span>
            {field.kind === "select" ? (
              <select
                style={inputStyle}
                value={values[field.key] ?? ""}
                onChange={(e) => setValue(field.key, e.target.value)}
              >
                {(field.options ?? []).map((option) => (
                  <option key={option} value={option}>
                    {option}
                  </option>
                ))}
              </select>
            ) : (
              <input
                style={{ ...inputStyle, width: field.kind === "amount" ? 100 : undefined }}
                type={field.kind === "amount" ? "number" : field.kind === "date" ? "date" : "text"}
                step={field.kind === "amount" ? "0.01" : undefined}
                min={field.kind === "amount" ? "0" : undefined}
                placeholder={field.placeholder}
                value={values[field.key] ?? ""}
                onChange={(e) => setValue(field.key, e.target.value)}
                onKeyDown={handleKeyDown}
              />
            )}
          </label>
        ))}
        <button
          type="button"
          onClick={submit}
          style={{
            background: colors.gold,
            border: "none",
            borderRadius: 6,
            color: colors.ink,
            fontWeight: 700,
            padding: "9px 14px",
            fontSize: 13,
            display: "flex",
            alignItems: "center",
            gap: 6,
            cursor: "pointer",
            height: 36,
            fontFamily: monoFont,
          }}
        >
          <PlusIcon size={15} /> {submitLabel}
        </button>
      </div>
      {error && <p style={{ color: colors.rust, fontSize: 12, margin: "8px 0 0" }}>{error}</p>}
    </div>
  );
}
