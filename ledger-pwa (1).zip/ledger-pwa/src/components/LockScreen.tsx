import { useRef, useState } from "react";
import type { CSSProperties, KeyboardEvent, ChangeEvent } from "react";
import { LockIcon } from "../icons/icons";
import { colors, monoFont, bodyFont } from "../styles/theme";
import type { VaultRecord } from "../types";
import { parseVaultFile, readFileAsText } from "../utils/vaultFile";

export type LockScreenMode = "setup" | "locked";

interface LockScreenProps {
  mode: LockScreenMode;
  /** Called for first-time vault creation. Should throw on failure. */
  onCreate: (password: string) => Promise<void>;
  /** Called to unlock an existing vault. Should throw if the password is wrong. */
  onUnlock: (password: string) => Promise<void>;
  /** Permanently erases the vault. Used only after explicit double-confirmation. */
  onResetVault: () => Promise<void>;
  /** Restores a previously-exported vault file, overwriting local data. */
  onImport: (record: VaultRecord) => Promise<void>;
}

const MIN_PASSWORD_LENGTH = 8;

export function LockScreen({ mode, onCreate, onUnlock, onResetVault, onImport }: LockScreenProps) {
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [confirmingReset, setConfirmingReset] = useState(false);
  const [importError, setImportError] = useState("");
  const [pendingImportRecord, setPendingImportRecord] = useState<VaultRecord | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const isSetup = mode === "setup";

  const handleFileSelected = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = ""; // allow re-selecting the same file later
    if (!file) return;

    setImportError("");
    try {
      const text = await readFileAsText(file);
      const record = parseVaultFile(text);
      if (isSetup) {
        // Nothing local to lose yet — import right away.
        await onImport(record);
      } else {
        // An existing vault is here; make the overwrite an explicit, confirmed step.
        setPendingImportRecord(record);
      }
    } catch (err) {
      setImportError(err instanceof Error ? err.message : "Could not read that file.");
    }
  };

  const confirmImport = async () => {
    if (!pendingImportRecord) return;
    try {
      await onImport(pendingImportRecord);
      setPendingImportRecord(null);
    } catch {
      setImportError("Could not restore that backup. Try again.");
    }
  };

  const submit = async () => {
    setError("");

    if (isSetup) {
      if (password.length < MIN_PASSWORD_LENGTH) {
        setError(`Use at least ${MIN_PASSWORD_LENGTH} characters. Longer is better — this is the only thing protecting your data.`);
        return;
      }
      if (password !== confirmPassword) {
        setError("Passwords do not match.");
        return;
      }
    } else if (!password) {
      setError("Enter your master password.");
      return;
    }

    setBusy(true);
    try {
      if (isSetup) {
        await onCreate(password);
      } else {
        await onUnlock(password);
      }
    } catch {
      // Deliberately generic: don't reveal whether the password was wrong
      // vs. the stored data being corrupted/tampered with.
      setError("Incorrect password, or the stored data is corrupted.");
    } finally {
      setBusy(false);
      setPassword("");
      setConfirmPassword("");
    }
  };

  const handleKeyDown = (e: KeyboardEvent) => {
    if (e.key === "Enter") submit();
  };

  return (
    <div style={{ minHeight: "100vh", background: colors.ink, display: "flex", alignItems: "center", justifyContent: "center", padding: 24, fontFamily: bodyFont }}>
      <div style={{ width: "100%", maxWidth: 360 }}>
        <div style={{ display: "flex", justifyContent: "center", marginBottom: 16, color: colors.gold }}>
          <LockIcon size={32} />
        </div>
        <h1 style={{ margin: 0, fontSize: 20, textAlign: "center", fontFamily: monoFont, letterSpacing: "0.04em", color: colors.gold }}>LEDGER</h1>
        <p style={{ textAlign: "center", fontSize: 13, color: colors.textMuted, margin: "8px 0 24px" }}>
          {isSetup ? "Create a master password to encrypt your data." : "Enter your master password to unlock."}
        </p>

        <input
          type="password"
          autoFocus
          placeholder="Master password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          onKeyDown={handleKeyDown}
          style={fieldStyle}
        />
        {isSetup && (
          <input
            type="password"
            placeholder="Confirm master password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            onKeyDown={handleKeyDown}
            style={{ ...fieldStyle, marginTop: 10 }}
          />
        )}

        {error && <p style={{ color: colors.rust, fontSize: 12, margin: "10px 0 0" }}>{error}</p>}

        <button onClick={submit} disabled={busy} style={submitButtonStyle}>
          {busy ? "Working…" : isSetup ? "Create & unlock" : "Unlock"}
        </button>

        {isSetup && (
          <p style={{ fontSize: 11, color: colors.textFaint, marginTop: 16, textAlign: "center", lineHeight: 1.5 }}>
            There is no password recovery. If you forget this password, your data cannot be decrypted by anyone —
            including you.
          </p>
        )}

        <input ref={fileInputRef} type="file" accept=".json,application/json" onChange={(e) => void handleFileSelected(e)} style={{ display: "none" }} />

        {isSetup && (
          <div style={{ marginTop: 16, textAlign: "center" }}>
            <button onClick={() => fileInputRef.current?.click()} style={linkButtonStyle}>
              Or restore from a backup file
            </button>
          </div>
        )}

        {importError && <p style={{ color: colors.rust, fontSize: 12, margin: "10px 0 0", textAlign: "center" }}>{importError}</p>}

        {!isSetup && (
          <div style={{ marginTop: 24, textAlign: "center" }}>
            {pendingImportRecord ? (
              <div style={{ background: colors.inkPanel, borderRadius: 8, padding: 14, marginTop: 8 }}>
                <p style={{ fontSize: 12, color: colors.rust, margin: "0 0 10px" }}>
                  This replaces everything currently stored on this device with the backup file. There is no undo.
                  You'll need the master password from whichever device the backup came from.
                </p>
                <div style={{ display: "flex", gap: 8, justifyContent: "center" }}>
                  <button
                    onClick={() => {
                      void confirmImport();
                    }}
                    style={{ background: colors.rust, border: "none", borderRadius: 6, color: colors.text, padding: "6px 12px", fontSize: 12, cursor: "pointer" }}
                  >
                    Yes, restore this backup
                  </button>
                  <button onClick={() => setPendingImportRecord(null)} style={linkButtonStyle}>
                    Cancel
                  </button>
                </div>
              </div>
            ) : !confirmingReset ? (
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                <button onClick={() => fileInputRef.current?.click()} style={linkButtonStyle}>
                  Restore from a backup file
                </button>
                <button onClick={() => setConfirmingReset(true)} style={linkButtonStyle}>
                  Forgot password? Erase all data and start over
                </button>
              </div>
            ) : (
              <div style={{ background: colors.inkPanel, borderRadius: 8, padding: 14, marginTop: 8 }}>
                <p style={{ fontSize: 12, color: colors.rust, margin: "0 0 10px" }}>
                  This permanently deletes everything stored on this device. There is no undo.
                </p>
                <div style={{ display: "flex", gap: 8, justifyContent: "center" }}>
                  <button
                    onClick={() => {
                      void onResetVault();
                    }}
                    style={{ background: colors.rust, border: "none", borderRadius: 6, color: colors.text, padding: "6px 12px", fontSize: 12, cursor: "pointer" }}
                  >
                    Yes, erase everything
                  </button>
                  <button onClick={() => setConfirmingReset(false)} style={linkButtonStyle}>
                    Cancel
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

const fieldStyle: CSSProperties = {
  width: "100%",
  boxSizing: "border-box",
  background: colors.inkPanel,
  border: `1px solid ${colors.inkInputBorder}`,
  borderRadius: 6,
  color: colors.text,
  padding: "10px 12px",
  fontSize: 14,
  fontFamily: "inherit",
  outline: "none",
};

const submitButtonStyle: CSSProperties = {
  width: "100%",
  marginTop: 14,
  background: colors.gold,
  border: "none",
  borderRadius: 6,
  color: colors.ink,
  fontWeight: 700,
  padding: "11px 14px",
  fontSize: 14,
  cursor: "pointer",
};

const linkButtonStyle: CSSProperties = {
  background: "none",
  border: "none",
  color: colors.textFaint,
  fontSize: 11,
  cursor: "pointer",
  textDecoration: "underline",
};
