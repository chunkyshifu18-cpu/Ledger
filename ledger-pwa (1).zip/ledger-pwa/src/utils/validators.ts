/**
 * Centralized input validation. Every form field in this app goes
 * through one of these two functions before it's stored, so there's one
 * place to check (and fix) validation logic rather than it being
 * scattered across every form component.
 */

const MAX_AMOUNT = 1_000_000_000; // one billion — well above any real personal budget, guards against overflow/typo garbage
const DEFAULT_MAX_TEXT_LENGTH = 200;

/**
 * Parses a raw string (from a number input) into a safe, finite,
 * positive amount rounded to cents, or null if it's not usable.
 *
 * Number(str) alone is not enough validation: Number("1e400") is
 * Infinity, and Infinity > 0 is true, which would silently corrupt the
 * ledger's totals. Number.isFinite() catches that.
 */
export function parseValidAmount(raw: string): number | null {
  const n = Number(raw);
  if (!Number.isFinite(n) || n <= 0 || n > MAX_AMOUNT) return null;
  return Math.round(n * 100) / 100;
}

/**
 * Same as parseValidAmount but allows zero (used for "clear this
 * category's planned budget back to $0").
 */
export function parseValidAmountOrZero(raw: string): number {
  if (raw.trim() === "") return 0;
  const n = Number(raw);
  if (!Number.isFinite(n) || n < 0 || n > MAX_AMOUNT) return 0;
  return Math.round(n * 100) / 100;
}

/**
 * Trims and length-caps free text before it's stored. React escapes all
 * text content by default (see the README's XSS note), so this isn't
 * about preventing script injection — it's about keeping stored data
 * well-formed and bounded in size.
 */
export function sanitizeText(raw: string, maxLength: number = DEFAULT_MAX_TEXT_LENGTH): string {
  return raw.trim().slice(0, maxLength);
}

export function isValidDateString(raw: string): boolean {
  return /^\d{4}-\d{2}-\d{2}$/.test(raw) && !Number.isNaN(new Date(raw).getTime());
}
