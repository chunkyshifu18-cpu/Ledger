/** crypto.randomUUID() is available in all browsers this app targets (secure contexts only, which PWAs require anyway). */
export function uid(): string {
  return crypto.randomUUID();
}
