/**
 * Turns the encrypted vault record into a downloadable file, and back.
 *
 * Important: this operates on the already-encrypted VaultRecord — the
 * salt, iteration count, IV, and ciphertext exactly as stored in
 * IndexedDB. Nothing is decrypted to export it, and nothing needs to be
 * decrypted to validate an imported file's shape. The exported file is
 * exactly as safe (or unsafe) as the ciphertext already sitting in your
 * browser's IndexedDB — safe to put in an email attachment or a cloud
 * drive folder precisely because it's still fully encrypted; anyone
 * who gets the file still needs your master password to read anything.
 */

import type { VaultRecord } from "../types";

export class InvalidVaultFileError extends Error {
  constructor() {
    super("This doesn't look like a valid Ledger backup file.");
    this.name = "InvalidVaultFileError";
  }
}

/** Type-guards and validates a parsed JSON value as a well-formed VaultRecord. */
export function parseVaultFile(text: string): VaultRecord {
  let parsed: unknown;
  try {
    parsed = JSON.parse(text);
  } catch {
    throw new InvalidVaultFileError();
  }

  if (
    typeof parsed === "object" &&
    parsed !== null &&
    "version" in parsed &&
    "salt" in parsed &&
    "iterations" in parsed &&
    "iv" in parsed &&
    "ciphertext" in parsed
  ) {
    const record = parsed as Record<string, unknown>;
    if (
      record.version === 1 &&
      typeof record.salt === "string" &&
      typeof record.iterations === "number" &&
      Number.isFinite(record.iterations) &&
      record.iterations > 0 &&
      typeof record.iv === "string" &&
      typeof record.ciphertext === "string"
    ) {
      return {
        version: 1,
        salt: record.salt,
        iterations: record.iterations,
        iv: record.iv,
        ciphertext: record.ciphertext,
      };
    }
  }

  throw new InvalidVaultFileError();
}

/** Reads a File (from a file input) as text. */
export function readFileAsText(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result ?? ""));
    reader.onerror = () => reject(reader.error ?? new Error("Could not read file"));
    reader.readAsText(file);
  });
}

/** Triggers a browser download of the vault record as a .json file. */
export function downloadVaultRecord(record: VaultRecord): void {
  const dateStamp = new Date().toISOString().slice(0, 10);
  const filename = `ledger-backup-${dateStamp}.json`;

  const blob = new Blob([JSON.stringify(record, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);

  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);

  // Release the object URL once the download has had a moment to start.
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
