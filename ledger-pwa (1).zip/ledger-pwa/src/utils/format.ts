export function fmt(n: number): string {
  return (Number(n) || 0).toLocaleString(undefined, { style: "currency", currency: "USD" });
}

export function todayStr(): string {
  return new Date().toISOString().slice(0, 10);
}

export function firstOfMonthStr(year: number, month: number): string {
  return new Date(year, month, 1).toISOString().slice(0, 10);
}

export function monthLabel(year: number, month: number): string {
  return new Date(year, month, 1).toLocaleDateString(undefined, { month: "long", year: "numeric" });
}

export function nextYearMonth(year: number, month: number): { year: number; month: number } {
  return month === 11 ? { year: year + 1, month: 0 } : { year, month: month + 1 };
}

/** clip-path polygon for the "torn receipt" bottom edge on the monthly summary card */
export const RECEIPT_TEETH_CLIP_PATH: string = (() => {
  const pts = ["0% 0%", "100% 0%", "100% 94%"];
  for (let x = 95; x >= 0; x -= 5) pts.push(`${x}% ${x % 10 === 0 ? 94 : 100}%`);
  return `polygon(${pts.join(",")})`;
})();
