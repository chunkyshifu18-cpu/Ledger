import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { registerSW } from "virtual:pwa-register";
import App from "./App";

const rootElement = document.getElementById("root");
if (!rootElement) {
  throw new Error("Missing #root element");
}

createRoot(rootElement).render(
  <StrictMode>
    <App />
  </StrictMode>
);

// Registering the service worker here — explicitly, in application code
// you can read — rather than via an auto-injected script is a deliberate
// choice: it's easy to see exactly what runs and when. `registerType:
// "autoUpdate"` (see vite.config.ts) means new versions activate
// automatically on the next load; there is no update-prompt UI to wire
// up here.
if ("serviceWorker" in navigator) {
  registerSW({ immediate: true });
}

// Ask the browser not to evict this site's storage under disk pressure.
// This matters most on iOS Safari, which can otherwise clear IndexedDB
// for sites that haven't been opened in a while (see SECURITY.md ->
// "Data loss risk on iOS"). This is a best-effort request, not a
// guarantee — the browser can still say no.
if (navigator.storage && navigator.storage.persist) {
  void navigator.storage.persist();
}
