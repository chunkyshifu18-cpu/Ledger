/**
 * A tiny, hand-written IndexedDB wrapper — no external library. The only
 * thing ever stored here is an encrypted blob (see types.ts VaultRecord):
 * a salt, an iteration count, an IV, and ciphertext. All four fields are
 * either public parameters or opaque encrypted bytes; none of them are
 * secret on their own. The plaintext financial data never reaches this
 * file.
 *
 * IndexedDB is used instead of localStorage because:
 *  - localStorage is synchronous and can block the main thread on large
 *    values; IndexedDB is async.
 *  - localStorage has no structured storage / transactions.
 *  - IndexedDB is the storage the PWA offline story is built around.
 */

import type { VaultRecord } from "../types";

const DB_NAME = "ledger-vault";
const DB_VERSION = 1;
const STORE_NAME = "vault";
const RECORD_KEY = "main";

function openDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME);
      }
    };

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error ?? new Error("Failed to open IndexedDB"));
  });
}

export async function loadVaultRecord(): Promise<VaultRecord | null> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readonly");
    const store = tx.objectStore(STORE_NAME);
    const request = store.get(RECORD_KEY);
    request.onsuccess = () => resolve((request.result as VaultRecord | undefined) ?? null);
    request.onerror = () => reject(request.error ?? new Error("Failed to read vault"));
  });
}

export async function saveVaultRecord(record: VaultRecord): Promise<void> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readwrite");
    const store = tx.objectStore(STORE_NAME);
    const request = store.put(record, RECORD_KEY);
    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error ?? new Error("Failed to save vault"));
  });
}

/** Used only by the explicit, confirmed "forgot password / erase everything" flow. */
export async function deleteVaultRecord(): Promise<void> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readwrite");
    const store = tx.objectStore(STORE_NAME);
    const request = store.delete(RECORD_KEY);
    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error ?? new Error("Failed to delete vault"));
  });
}
