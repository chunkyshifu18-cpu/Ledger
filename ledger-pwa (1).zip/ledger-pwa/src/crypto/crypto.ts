/**
 * All encryption for this app goes through this one file. Keeping it
 * small and isolated makes it the single place to audit if you want to
 * verify the security claims made elsewhere in the app.
 *
 * Design summary:
 *  - Master password -> PBKDF2-SHA256 (310,000 iterations) -> AES-256-GCM key
 *  - The derived key is created as `extractable: false`, meaning the raw
 *    key bytes are never accessible to JavaScript at any point — not even
 *    to this file. The browser's crypto engine holds them internally.
 *    This is stronger than "we don't store it", because there is no
 *    variable anywhere in memory holding the raw key that could be
 *    accidentally logged, serialized, or read by another script.
 *  - Every encryption uses a fresh random 96-bit IV. Reusing an IV with
 *    the same AES-GCM key is a catastrophic, decryption-breaking mistake
 *    (it leaks the XOR of two plaintexts and can leak the auth key) — so
 *    encryptJSON() below generates a new one on every single call and
 *    never accepts a caller-supplied IV.
 *  - Wrong-password detection is "free": AES-GCM includes an
 *    authentication tag, so decrypting with the wrong key throws
 *    (OperationError) instead of silently returning garbage. We rely on
 *    that instead of storing any kind of password hash or verifier.
 */

/** OWASP's current (2023+) minimum recommendation for PBKDF2-SHA256. */
export const DEFAULT_PBKDF2_ITERATIONS = 310_000;

const AES_KEY_LENGTH_BITS = 256;
const IV_LENGTH_BYTES = 12; // 96 bits — the size AES-GCM is designed for
const SALT_LENGTH_BYTES = 16;

export interface EncryptedPayload {
  iv: string; // base64
  ciphertext: string; // base64
}

function bytesToBase64(bytes: ArrayBuffer | Uint8Array): string {
  const arr = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
  let binary = "";
  for (let i = 0; i < arr.length; i++) {
    binary += String.fromCharCode(arr[i]!);
  }
  return btoa(binary);
}

function base64ToBytes(b64: string): Uint8Array {
  const binary = atob(b64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}

/** A fresh random salt for a brand-new vault. Not secret — safe to store alongside the ciphertext. */
export function generateSalt(): Uint8Array {
  return crypto.getRandomValues(new Uint8Array(SALT_LENGTH_BYTES));
}

export function saltToBase64(salt: Uint8Array): string {
  return bytesToBase64(salt);
}

export function saltFromBase64(b64: string): Uint8Array {
  return base64ToBytes(b64);
}

/**
 * Derives a non-extractable AES-GCM CryptoKey from the user's password.
 * This is the only function in the app that ever touches the raw
 * password string. The password itself is never written to any variable
 * outside this call stack, and is never persisted anywhere.
 */
export async function deriveKey(
  password: string,
  salt: Uint8Array,
  iterations: number = DEFAULT_PBKDF2_ITERATIONS
): Promise<CryptoKey> {
  const encoder = new TextEncoder();

  // Import the raw password as PBKDF2 key material. This key can only be
  // used to derive other keys — it can't itself encrypt anything.
  const passwordKeyMaterial = await crypto.subtle.importKey(
    "raw",
    encoder.encode(password),
    "PBKDF2",
    false,
    ["deriveKey"]
  );

  return crypto.subtle.deriveKey(
    { name: "PBKDF2", salt, iterations, hash: "SHA-256" },
    passwordKeyMaterial,
    { name: "AES-GCM", length: AES_KEY_LENGTH_BITS },
    false, // extractable: false — see the file header comment
    ["encrypt", "decrypt"]
  );
}

/** Encrypts a JSON-serializable value with a fresh random IV. */
export async function encryptJSON(key: CryptoKey, data: unknown): Promise<EncryptedPayload> {
  const iv = crypto.getRandomValues(new Uint8Array(IV_LENGTH_BYTES));
  const plaintext = new TextEncoder().encode(JSON.stringify(data));

  const ciphertextBuf = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, plaintext);

  return {
    iv: bytesToBase64(iv),
    ciphertext: bytesToBase64(ciphertextBuf),
  };
}

/**
 * Decrypts and JSON-parses a payload. Throws if the key is wrong (bad
 * password) or the data was tampered with / corrupted — AES-GCM's
 * built-in authentication tag makes those two cases indistinguishable
 * from the outside, which is intentional: we don't want to leak *why*
 * decryption failed.
 */
export async function decryptJSON<T>(key: CryptoKey, payload: EncryptedPayload): Promise<T> {
  const iv = base64ToBytes(payload.iv);
  const ciphertext = base64ToBytes(payload.ciphertext);

  const plaintextBuf = await crypto.subtle.decrypt({ name: "AES-GCM", iv }, key, ciphertext);

  const json = new TextDecoder().decode(plaintextBuf);
  return JSON.parse(json) as T;
}
