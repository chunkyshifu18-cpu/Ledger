import type { LedgerData } from "../types";
import { uid } from "../utils/id";

export const DEFAULT_CATEGORIES: string[] = [
  "Housing",
  "Food",
  "Transport",
  "Utilities",
  "Entertainment",
  "Health",
  "Other",
];

export function createEmptyLedger(): LedgerData {
  const now = new Date();
  return {
    months: [
      {
        id: uid(),
        year: now.getFullYear(),
        month: now.getMonth(),
        income: [],
        expenses: [],
        budgetPlan: { income: [], expenses: {} },
      },
    ],
    recurring: [],
    categories: [...DEFAULT_CATEGORIES],
  };
}
