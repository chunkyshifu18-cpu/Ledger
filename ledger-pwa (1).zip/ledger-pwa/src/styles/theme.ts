import type { CSSProperties } from "react";

export const colors = {
  ink: "#12192B",
  inkPanel: "#1A2440",
  inkBorder: "#202B45",
  inkInputBorder: "#2C3A5A",
  paper: "#F6F4EC",
  paperMuted: "#8A8672",
  paperBorder: "#C9C4AE",
  text: "#F5F3EC",
  textMuted: "#8A93A6",
  textFaint: "#5B6472",
  textDisabled: "#3A4560",
  gold: "#C9A227",
  forest: "#2F6F4E",
  rust: "#B0453A",
};

export const monoFont = "'JetBrains Mono', Menlo, Consolas, monospace";
export const bodyFont = "ui-sans-serif, system-ui, -apple-system, sans-serif";

export const inputStyle: CSSProperties = {
  background: colors.inkPanel,
  border: `1px solid ${colors.inkInputBorder}`,
  borderRadius: 6,
  color: colors.text,
  padding: "8px 10px",
  fontSize: 14,
  fontFamily: "inherit",
  outline: "none",
};

export const smallInputStyle: CSSProperties = {
  ...inputStyle,
  padding: "6px 8px",
  fontSize: 13,
};

export const labelStyle: CSSProperties = {
  fontFamily: monoFont,
  letterSpacing: "0.05em",
  textTransform: "uppercase",
  fontSize: 10,
};

export const sectionHeadingStyle: CSSProperties = {
  fontSize: 11,
  letterSpacing: "0.08em",
  textTransform: "uppercase",
  color: colors.textFaint,
  marginBottom: 12,
  fontFamily: monoFont,
};
