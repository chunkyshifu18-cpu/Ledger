# Ledger — a private, offline budget tracker

A personal budget tracker that runs entirely in your browser. Every
number you enter is encrypted on your device before it's ever written to
disk, nothing is ever sent to a server (there isn't one), and it works
fully offline once installed.

- **React + TypeScript**, built with Vite
- **Installable PWA** — Windows, Android, iPhone
- **AES-256-GCM encryption**, key derived from your password with
  PBKDF2 (310,000 iterations)
- **IndexedDB** storage, encrypted blob only
- **No accounts, no server, no analytics, no external scripts**
- Free to host on **GitHub Pages** or **Cloudflare Pages**

Read `SECURITY.md` for the full threat model and a list of known
tradeoffs — please read it before trusting this with real financial
data.

---

## Project layout

```
ledger-pwa/
├── .github/workflows/deploy.yml   # auto-deploy to GitHub Pages
├── public/
│   ├── icons/                     # app icons (already generated)
│   └── _headers                   # Cloudflare Pages security headers
├── src/
│   ├── crypto/crypto.ts           # ALL encryption code lives here
│   ├── storage/db.ts              # IndexedDB wrapper (encrypted blob only)
│   ├── data/defaultData.ts        # empty-ledger factory
│   ├── hooks/useInactivityLock.ts # 10-minute auto-lock timer
│   ├── utils/                     # formatting, id generation, input validation
│   ├── icons/icons.tsx            # small hand-written icon set (no icon package)
│   ├── components/                # LockScreen, BudgetTracker, and its sub-parts
│   ├── styles/theme.ts            # shared style constants
│   ├── App.tsx                    # vault lifecycle: setup / locked / unlocked
│   ├── main.tsx                   # React root + service worker registration
│   └── types.ts                   # shared TypeScript types
├── index.html                     # CSP <meta> tag lives here
├── vite.config.ts                 # PWA / service worker config
└── package.json
```

---

## 1. Run it locally

Requires [Node.js](https://nodejs.org) 20 or newer.

```bash
npm install
npm run dev
```

Open the URL it prints (usually `http://localhost:5173`). Hot-reloading
is on; the service worker is intentionally **disabled** in dev mode
(`devOptions.enabled: false` in `vite.config.ts`) so caching never gets
in the way of seeing your latest changes.

> `npm install` needs internet access the first time, to download React,
> Vite, and TypeScript from npm — all free, open-source packages. Once
> installed, the *app itself* runs 100% offline; this is only about the
> build tooling.

## 2. Build it for production

```bash
npm run build
```

This runs a TypeScript check (`tsc -b`) and then Vite's production
build. Output goes to `dist/` — a folder of static files (HTML, JS, CSS,
icons, manifest, service worker) that you can host anywhere that serves
static files.

Preview the production build locally before deploying:

```bash
npm run preview
```

## 3. Publish it for free on GitHub Pages

**Option A — automatic (recommended):**

1. Create a new GitHub repository and push this project to it.
2. In the repo, go to **Settings → Pages → Build and deployment → Source**
   and select **GitHub Actions**.
3. Push to `main`. The included workflow
   (`.github/workflows/deploy.yml`) builds and deploys automatically.
   Check the **Actions** tab for progress.
4. Your app is live at `https://<your-username>.github.io/<repo-name>/`.

Because `vite.config.ts` uses `base: "./"` (relative paths), this works
correctly at that subpath with no further configuration.

**Option B — manual:**

```bash
npm run build
# then push the contents of dist/ to a `gh-pages` branch,
# or upload it via the Pages UI's manual-deploy option.
```

**Alternative: Cloudflare Pages** (also free, and gives you real HTTP
security headers via `public/_headers`, which GitHub Pages can't do):

1. Push the repo to GitHub (or GitLab).
2. In the Cloudflare dashboard: **Workers & Pages → Create → Pages →
   Connect to Git**, pick the repo.
3. Build command: `npm run build`. Build output directory: `dist`.
4. Deploy. Cloudflare auto-detects Vite and everything above just works.

## 4. Install as a PWA on Windows

1. Open your deployed URL in **Edge** or **Chrome**.
2. Click the **install icon** in the address bar (a monitor-with-arrow
   icon), or open the browser menu → **Apps → Install this site as an
   app**.
3. Confirm. Ledger now opens in its own window from the Start Menu, with
   no browser chrome, and keeps working offline.

## 5. Install as a PWA on Android

1. Open your deployed URL in **Chrome**.
2. Tap the **⋮** menu → **Add to Home screen** (Chrome may also show an
   automatic "Install app" banner — either works).
3. Confirm. An app icon appears on your home screen and in your app
   drawer, launching full-screen with no browser UI.

## 6. Install as a PWA on iPhone

iOS only supports installing PWAs through **Safari** (not Chrome, even
though Chrome is available — this is an Apple platform restriction, not
a limitation of this app).

1. Open your deployed URL in **Safari**.
2. Tap the **Share** icon (square with an arrow) in the toolbar.
3. Scroll down and tap **Add to Home Screen**.
4. Confirm. The app icon appears on your home screen and launches
   standalone.

> iOS note: Safari can occasionally clear site storage (including
> IndexedDB) for sites that haven't been opened in a while, or under
> storage pressure. See `SECURITY.md` → "Data loss risk on iOS" for what
> this means for you and how to protect against it.

---

## Updating the app after you've deployed it

Just push new commits to `main` (or re-run the Cloudflare build). The
service worker (`registerType: "autoUpdate"` in `vite.config.ts`) picks
up new builds automatically the next time the installed app is opened
with a network connection — you don't need to reinstall it.

## Syncing between devices

This app has no server, so there's no automatic sync — but you can move
your encrypted vault between devices manually:

1. **On the device with your data:** open the app, unlock it, and click
   **Export** in the header. This downloads a `ledger-backup-YYYY-MM-DD.json`
   file — the encrypted vault exactly as it's stored locally, nothing
   decrypted in the process.
2. **Get that file to your other device.** Easiest way: save it into a
   folder that a cloud drive you already use (iCloud Drive, Google
   Drive, OneDrive, Dropbox) syncs automatically. AirDrop, email, or a
   USB cable work too.
3. **On the other device:** open the app.
   - If it's brand new (no vault yet), the setup screen has an
     **"Or restore from a backup file"** link — pick the file you just
     transferred instead of creating a new password.
   - If it already has a vault, the lock screen has a
     **"Restore from a backup file"** link. This will ask you to confirm,
     since it overwrites whatever's currently on that device.
4. Enter the master password **from the device the backup came from**
   (not necessarily the one you'd been using on this device, if they
   differed) to unlock it.

This is a manual, one-directional "copy the whole vault" operation, not
a merge — whichever device you import into ends up with an exact copy
of the exported vault, and anything that device had that wasn't in the
backup is gone. Export again after making changes on either device
before switching to the other one.

## Changing your master password

There's currently no in-app "change password" flow — this was left out
deliberately to keep the encryption code small and easy to audit (see
`SECURITY.md`). To change your password today, you'd need to add an
"decrypt with old key, re-encrypt with a freshly derived new key" step
in `App.tsx`; the crypto primitives in `src/crypto/crypto.ts` already
support this directly if you want to add it yourself.

**There is no password reset.** If you forget your master password,
your data cannot be recovered by anyone, including you — that's what
"only you can decrypt it" means. The lock screen has a "forgot password
/ erase everything" option that wipes the vault and lets you start over
with a new one; it does not recover the old data.
