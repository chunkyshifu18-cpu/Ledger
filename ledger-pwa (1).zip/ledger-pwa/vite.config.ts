import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { VitePWA } from "vite-plugin-pwa";

// https://vitejs.dev/config/
export default defineConfig({
  // A relative base means the built app works whether it's hosted at a
  // domain root (Cloudflare Pages) or a subpath (GitHub Pages project
  // sites, e.g. https://user.github.io/ledger-pwa/). No per-host config
  // needed.
  base: "./",

  plugins: [
    react(),

    // vite-plugin-pwa generates the service worker at build time using
    // Workbox, with the exact hashed filenames of everything Vite just
    // built baked into its precache list. This is what makes "works
    // completely offline after first visit" actually reliable — a
    // hand-written service worker would need to guess or hard-code
    // those filenames and would silently go stale after every build.
    VitePWA({
      registerType: "autoUpdate",
      injectRegister: false, // we register the SW ourselves in src/main.tsx, explicitly and visibly
      includeAssets: [
        "icons/icon-192.png",
        "icons/icon-512.png",
        "icons/apple-touch-icon.png",
        "icons/favicon-32.png",
      ],
      manifest: {
        name: "Ledger — Private Budget Tracker",
        short_name: "Ledger",
        description:
          "A private, offline-first budget tracker. Every entry is encrypted on your device before it's ever saved; nothing is sent anywhere.",
        theme_color: "#12192B",
        background_color: "#12192B",
        display: "standalone",
        start_url: ".",
        scope: ".",
        icons: [
          { src: "icons/icon-192.png", sizes: "192x192", type: "image/png", purpose: "any" },
          { src: "icons/icon-192.png", sizes: "192x192", type: "image/png", purpose: "maskable" },
          { src: "icons/icon-512.png", sizes: "512x512", type: "image/png", purpose: "any" },
          { src: "icons/icon-512.png", sizes: "512x512", type: "image/png", purpose: "maskable" },
        ],
      },
      workbox: {
        // Precache every built asset (JS, CSS, HTML, icons) so the app
        // shell loads with zero network requests once installed.
        globPatterns: ["**/*.{js,css,html,png,svg,webmanifest}"],
        cleanupOutdatedCaches: true,
        // This app has no server API to call, so there is no runtime
        // caching config here on purpose — everything the app needs is
        // precached, and nothing else is ever fetched.
      },
      devOptions: {
        enabled: false, // don't run a service worker during `vite dev`; it makes debugging confusing
      },
    }),
  ],

  build: {
    // Keep the output easy to audit: no source maps shipped by default
    // (financial-app source shouldn't be trivially reconstructable from
    // a public deployment), predictable asset layout.
    sourcemap: false,
    outDir: "dist",
  },
});
